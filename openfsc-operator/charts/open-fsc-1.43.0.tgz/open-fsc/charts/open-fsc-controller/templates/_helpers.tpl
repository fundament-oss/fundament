{{/* vim: set filetype=mustache: */}}
{{/*
Expand the name of the chart.
*/}}
{{- define "open-fsc-controller.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "open-fsc-controller.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default .Chart.Name .Values.nameOverride -}}
{{- if contains $name .Release.Name -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "open-fsc-controller.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Common labels
*/}}
{{- define "open-fsc-controller.labels" -}}
helm.sh/chart: {{ include "open-fsc-controller.chart" . }}
{{ include "open-fsc-controller.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end -}}

{{/*
Selector labels
*/}}
{{- define "open-fsc-controller.selectorLabels" -}}
app.kubernetes.io/name: {{ include "open-fsc-controller.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end -}}

{{/*
Create the name of the service account to use
*/}}
{{- define "open-fsc-controller.serviceAccountName" -}}
{{- if .Values.serviceAccount.create -}}
    {{ default (include "open-fsc-controller.fullname" .) .Values.serviceAccount.name }}
{{- else -}}
    {{ default "default" .Values.serviceAccount.name }}
{{- end -}}
{{- end -}}

{{/*
Return the image name
*/}}
{{- define "open-fsc-controller.image" -}}
{{- $registryName := default .Values.image.registry .Values.global.imageRegistry -}}
{{- $repositoryName := .Values.image.repository -}}
{{- $tag := default (printf "v%s" .Chart.AppVersion) (default .Values.image.tag .Values.global.imageTag) -}}

{{- printf "%s/%s:%s" $registryName $repositoryName $tag -}}
{{- end -}}

{{/*
Return the secret name of the PostgreSQL username/password
*/}}
{{- define "open-fsc-controller.postgresql.secret" -}}
{{- default (printf "%s-postgresql" (include "open-fsc-controller.fullname" .)) .Values.postgresql.existingSecret.name -}}
{{- end -}}

{{/*
Return the secret name of the authn OIDC secrets
*/}}
{{- define "open-fsc-controller.authn.oidc.secret" -}}
{{- default (printf "%s-oidc" (include "open-fsc-controller.fullname" . )) .Values.config.authn.oidc.existingSecret.name -}}
{{- end -}}

{{/*
Return the secret name of the CSRF Authkey
*/}}
{{- define "open-fsc-controller.csrfAuthKey.secret" -}}
{{- default (printf "%s-csrf-auth-key" (include "open-fsc-controller.fullname" .)) .Values.config.csrfProtection.authKeyExistingSecret -}}
{{- end -}}

{{/*
Return the image pull secrets
*/}}
{{- define "open-fsc-controller.imagePullSecrets" -}}
  {{- $imagePullSecrets := default .Values.image.pullSecrets .Values.global.imagePullSecrets -}}
  {{- toYaml $imagePullSecrets | nindent 8 }}
{{- end -}}
