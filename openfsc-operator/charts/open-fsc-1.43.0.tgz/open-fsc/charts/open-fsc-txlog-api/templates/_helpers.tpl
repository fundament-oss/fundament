{{/*
Expand the name of the chart.
*/}}
{{- define "open-fsc-txlog-api.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "open-fsc-txlog-api.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "open-fsc-txlog-api.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "open-fsc-txlog-api.labels" -}}
helm.sh/chart: {{ include "open-fsc-txlog-api.chart" . }}
{{ include "open-fsc-txlog-api.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "open-fsc-txlog-api.selectorLabels" -}}
app.kubernetes.io/name: {{ include "open-fsc-txlog-api.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "open-fsc-txlog-api.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "open-fsc-txlog-api.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Return the image name for the open-fsc-txlog-api
*/}}
{{- define "open-fsc-txlog-api.image" -}}
{{- $registryName := default .Values.image.registry .Values.global.imageRegistry -}}
{{- $repositoryName := .Values.image.repository -}}
{{- $tag := default (printf "v%s" .Chart.AppVersion) (default .Values.image.tag .Values.global.imageTag) -}}

{{- printf "%s/%s:%s" $registryName $repositoryName $tag -}}
{{- end -}}

{{/*
Return the secret name of the PostgreSQL username/password
*/}}
{{- define "open-fsc-txlog-api.txlogdb.secret" -}}
{{- default (printf "%s-postgresql" (include "open-fsc-txlog-api.fullname" .)) .Values.txlogdb.existingSecret.name -}}
{{- end -}}

{{/*
Return the image pull secrets for the open-fsc-txlog-api
*/}}
{{- define "open-fsc-txlog-api.imagePullSecrets" -}}
  {{- $imagePullSecrets := default .Values.image.pullSecrets .Values.global.imagePullSecrets -}}
  {{- toYaml $imagePullSecrets | nindent 8 }}
{{- end -}}
