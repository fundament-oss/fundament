{{/*
Expand the name of the chart.
*/}}
{{- define "open-fsc-auditlog.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "open-fsc-auditlog.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "open-fsc-auditlog.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "open-fsc-auditlog.labels" -}}
helm.sh/chart: {{ include "open-fsc-auditlog.chart" . }}
{{ include "open-fsc-auditlog.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "open-fsc-auditlog.selectorLabels" -}}
app.kubernetes.io/name: {{ include "open-fsc-auditlog.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "open-fsc-auditlog.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "open-fsc-auditlog.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Return the image name for the open-fsc-auditlog
*/}}
{{- define "open-fsc-auditlog.image" -}}
{{- $registryName := default .Values.image.registry .Values.global.imageRegistry -}}
{{- $repositoryName := .Values.image.repository -}}
{{- $tag := default (printf "v%s" .Chart.AppVersion) (default .Values.image.tag .Values.global.imageTag) -}}

{{- printf "%s/%s:%s" $registryName $repositoryName $tag -}}
{{- end -}}

{{/*
Return the secret name of the PostgreSQL username/password
*/}}
{{- define "open-fsc-auditlog.db.secret" -}}
{{- default (printf "%s-postgresql" (include "open-fsc-auditlog.fullname" .)) .Values.db.existingSecret.name -}}
{{- end -}}

{{/*
Return the image pull secrets for the open-fsc-auditlog
*/}}
{{- define "open-fsc-auditlog.imagePullSecrets" -}}
  {{- $imagePullSecrets := default .Values.image.pullSecrets .Values.global.imagePullSecrets -}}
  {{- toYaml $imagePullSecrets | nindent 8 }}
{{- end -}}
