# Manager

OpenFSC Manager.

## Prerequisites

-   Kubernetes 1.11+

## Installing the Chart

To install the Chart with the release name `manager`:

```console
$ helm install manager oci://registry-1.docker.io/federatedserviceconnectivity/open-fsc-manager --version {latest version}
```

> **Tip**: List all releases using `helm list`

## Upgrading the Chart

Currently, our Helm charts use the same release version as the OpenFSC release version.
To know what has changed for the Helm charts, look at the changes in our [CHANGELOG](https://gitlab.com/rinis-oss/fsc/open-fsc/-/blob/main/CHANGELOG.md)
that are prefixed with 'Helm'.

## Uninstalling the Chart

To uninstall or delete the `manager` deployment:

```console
$ helm delete manager
```

## Parameters

### Global parameters

| Name                                                               | Description                                                                                                                                       | Value     |
| ------------------------------------------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------- | --------- |
| `global.imageRegistry`                                             | Global Docker Image registry                                                                                                                      | `""`      |
| `global.imageTag`                                                  | Global Docker Image tag                                                                                                                           | `""`      |
| `global.groupID`                                                   | Global FSC Group ID                                                                                                                               | `""`      |
| `global.imagePullSecrets`                                          | Global image pull secrets                                                                                                                         | `[]`      |
| `global.certificates.group.caCertificatePEM`                       | OpenFSC CA root certificate. If not set the value of 'certificates.group.caCertificatePEM' is used.                                               | `""`      |
| `global.certificates.group.caCertificatePEMExistingSecret.name`    | Name of the existing secret                                                                                                                       | `""`      |
| `global.certificates.group.caCertificatePEMExistingSecret.key`     | The key in the secret that contains the certificate                                                                                               | `tls.crt` |
| `global.certificates.internal.caCertificatePEM`                    | Global CA root certificate of your internal PKI. If not set the value of 'certificates.internal.caCertificatePEM' is used                         | `""`      |
| `global.certificates.internal.caCertificatePEMExistingSecret.name` | Name of the existing secret                                                                                                                       | `""`      |
| `global.certificates.internal.caCertificatePEMExistingSecret.key`  | The key in the secret that contains the certificate                                                                                               | `tls.crt` |
| `global.certificates.internalUnauthenticated.caCertificatePEM`     | CA root certificate of your internal unauthenticated PKI. If not set the value of 'certificates.internalUnauthenticated.caCertificatePEM' is used | `""`      |

### Deployment Parameter

| Name                                       | Description                                                                                                            | Value                                  |
| ------------------------------------------ | ---------------------------------------------------------------------------------------------------------------------- | -------------------------------------- |
| `image.registry`                           | Image registry (ignored if 'global.imageRegistry' is set)                                                              | `docker.io`                            |
| `image.repository`                         | Image repository of the manager API.                                                                                   | `federatedserviceconnectivity/manager` |
| `image.tag`                                | Image tag (ignored if 'global.imageTag' is set). When set to null, the AppVersion from the chart is used               | `""`                                   |
| `image.pullPolicy`                         | Image pull policy                                                                                                      | `Always`                               |
| `image.pullSecrets`                        | Secrets for the image repository                                                                                       | `[]`                                   |
| `serviceAccount.create`                    | Specifies whether a service account should be created                                                                  | `true`                                 |
| `serviceAccount.annotations`               | Annotations to add to the service account                                                                              | `{}`                                   |
| `serviceAccount.name`                      | The name of the service account to use. If not set and create is true, a name is generated using the fullname template | `""`                                   |
| `replicaCount`                             | Number of controller replicas                                                                                          | `1`                                    |
| `deploymentAnnotations`                    | Annotations to add to the deployment                                                                                   | `{}`                                   |
| `podAnnotations`                           | annotations added to the pod                                                                                           | `{}`                                   |
| `podLabels`                                | Extra labels added to the pod                                                                                          | `{}`                                   |
| `podSecurityContext.fsGroup`               | GroupID under which the pod should be started                                                                          | `1001`                                 |
| `securityContext.allowPrivilegeEscalation` | Controls whether a process can gain more privileges than its parent process                                            | `false`                                |
| `securityContext.runAsNonRoot`             | Run container as a non-root user                                                                                       | `true`                                 |
| `securityContext.runAsUser`                | Run container as specified user                                                                                        | `1001`                                 |
| `securityContext.capabilities.drop`        | Drop all capabilities by default                                                                                       | `["ALL"]`                              |
| `resources`                                | Pod resource requests & limits                                                                                         | `{}`                                   |
| `nodeSelector`                             | Node labels for pod assignment                                                                                         | `{}`                                   |
| `tolerations`                              | Node tolerations for pod assignment                                                                                    | `[]`                                   |
| `extraEnv`                                 | Extra env items for pod assignment                                                                                     | `[]`                                   |
| `affinity`                                 | Node affinity for pod assignment                                                                                       | `{}`                                   |

### Common Parameters

| Name               | Description                   | Value |
| ------------------ | ----------------------------- | ----- |
| `nameOverride`     | Override deployment name      | `""`  |
| `fullnameOverride` | Override full deployment name | `""`  |

### OpenFSC Manager parameters

| Name                                                                            | Description                                                                                                                                                                                                                                                                                                             | Value    |
| ------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | -------- |
| `config.logType`                                                                | Possible values 'live', 'local'. Affects the log output. See NewProduction and NewDevelopment at https://godoc.org/go.uber.org/zap#Logger                                                                                                                                                                               | `live`   |
| `config.logLevel`                                                               | Possible values 'debug', 'warn', 'info'. Override the default logLevel set by 'config.logType'                                                                                                                                                                                                                          | `info`   |
| `config.groupID`                                                                | FSC Group ID                                                                                                                                                                                                                                                                                                            | `""`     |
| `config.selfAddress`                                                            | The Address that can be used by the OpenFSC Group to reach this Manager                                                                                                                                                                                                                                                 | `""`     |
| `config.controllerRegistrationApiAddress`                                       | The address of the Controller Registration API                                                                                                                                                                                                                                                                          | `""`     |
| `config.txLogAPIAddress`                                                        | The Address of the Transaction Log API. Can be empty when this Manager functions as the Directory of the Group                                                                                                                                                                                                          | `""`     |
| `config.tokenTTL`                                                               | Duration of token validity, how long is the time to live for the generated tokens, format is specified in string, e.g. '1h', '300s', or '5m'## @param config.directoryPeerID The ID of the Peer acting as the Directory                                                                                                 | `1h`     |
| `config.directoryPeerID`                                                        | The ID of the Peer acting as the Directory                                                                                                                                                                                                                                                                              | `""`     |
| `config.directoryManagerAddress`                                                | The address of the Manager acting as the Directory                                                                                                                                                                                                                                                                      | `""`     |
| `config.autoSignGrants`                                                         | The contracts containing grants which should be signed automatically                                                                                                                                                                                                                                                    | `[]`     |
| `config.autoSignPolicyDecisionPointAddress`                                     | Address of the policy decision point which decides if a submitted Contract should get an automatic accept signature (DEPRECATED use autoSignPolicyDecisionPoint.url instead)                                                                                                                                            | `""`     |
| `config.autoSignPolicyDecisionPoint.enabled`                                    | If a policy decision point should be used to automatically sign contracts                                                                                                                                                                                                                                               | `false`  |
| `config.autoSignPolicyDecisionPoint.url`                                        | URL of the policy decision point                                                                                                                                                                                                                                                                                        | `""`     |
| `config.autoSignPolicyDecisionPoint.caCertificatePEMExistingSecret.name`        | Name of an existing secret that contains the CA certificate                                                                                                                                                                                                                                                             | `""`     |
| `config.autoSignPolicyDecisionPoint.caCertificatePEMExistingSecret.key`         | Key in the existing secret that contains the CA certificate                                                                                                                                                                                                                                                             | `ca.crt` |
| `config.autoSignAuthZenPolicyDecisionPointAddress`                              | Address of the AuthZen policy decision point which decides if a submitted Contract should get an automatic accept signature (DEPRECATED use autoSignAuthZenPolicyDecisionPoint.url instead)                                                                                                                             | `""`     |
| `config.autoSignAuthZenPolicyDecisionPoint.enabled`                             | If an AuthZen policy decision point should be used to automatically sign contracts                                                                                                                                                                                                                                      | `false`  |
| `config.autoSignAuthZenPolicyDecisionPoint.url`                                 | URL of the AuthZen policy decision point                                                                                                                                                                                                                                                                                | `""`     |
| `config.autoSignAuthZenPolicyDecisionPoint.caCertificatePEMExistingSecret.name` | Name of an existing secret that contains the CA certificate                                                                                                                                                                                                                                                             | `""`     |
| `config.autoSignAuthZenPolicyDecisionPoint.caCertificatePEMExistingSecret.key`  | Key in the existing secret that contains the CA certificate                                                                                                                                                                                                                                                             | `ca.crt` |
| `config.auditlog.type`                                                          | Possible values 'stdout', 'rest'. Type of the auditlogger                                                                                                                                                                                                                                                               | `stdout` |
| `config.auditlog.rest.address`                                                  | address of the Audit log                                                                                                                                                                                                                                                                                                | `""`     |
| `config.additionalClaimsAPIAddress`                                             | The address of the Additional Claims API. When configured, the API will be called each time the Manager returns an Access Token.                                                                                                                                                                                        | `""`     |
| `config.disableCrlChecks`                                                       | If 'true', CRLs on Certificates will be ignored. This means the Manager will accept Client Certificates that have been revoked, connect with other Managers that might use a revoked server Certificate and will hand out a token even if one of the signatures on the Contract is created using a revoked Certificate. | `false`  |

### Certificates parameters

| Name                                                                       | Description                                                                                                                                                                           | Value     |
| -------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | --------- |
| `certificates.internal.caCertificatePEM`                                   | The CA root certificate of your internal PKI                                                                                                                                          | `""`      |
| `certificates.internal.caCertificatePEMExistingSecret.name`                | Name of the existing secret                                                                                                                                                           | `""`      |
| `certificates.internal.caCertificatePEMExistingSecret.key`                 | The key in the secret that contains the certificates                                                                                                                                  | `""`      |
| `certificates.internal.certificatePEM`                                     | The certificate signed by your internal PKI                                                                                                                                           | `""`      |
| `certificates.internal.keyPEM`                                             | the private key of 'certificates.internal.certificatePEM'                                                                                                                             | `""`      |
| `certificates.internal.existingSecret`                                     | Use of existing secret with your OpenFSC keypair ('certificates.internal.certificatePEM' and 'certificates.internal.keyPEM'. will be ingored and picked up from this secret)A         | `""`      |
| `certificates.internalUnauthenticated.caCertificatePEM`                    | The CA root certificate of your internal authenticated PKI                                                                                                                            | `""`      |
| `certificates.internalUnauthenticated.caCertificatePEMExistingSecret.name` | Name of the existing secret                                                                                                                                                           | `""`      |
| `certificates.internalUnauthenticated.caCertificatePEMExistingSecret.key`  | The key in the secret that contains the certificates                                                                                                                                  | `tls.crt` |
| `certificates.internalUnauthenticated.certificatePEM`                      | the  certificate used in the unauthenticated internal service                                                                                                                         | `""`      |
| `certificates.internalUnauthenticated.keyPEM`                              | the private key used in the unauthenticated internal service                                                                                                                          | `""`      |
| `certificates.internalUnauthenticated.existingSecret`                      | use existing secret with the OpenFSC keypair used for the unauthenticated endpoint                                                                                                    | `""`      |
| `certificates.group.caCertificatePEM`                                      | The CA root certificate of the Group                                                                                                                                                  | `""`      |
| `certificates.group.caCertificatePEMExistingSecret.name`                   | Name of the existing secret                                                                                                                                                           | `""`      |
| `certificates.group.caCertificatePEMExistingSecret.key`                    | The key in the secret that contains the certificates                                                                                                                                  | `""`      |
| `certificates.group.peer.keyPEM`                                           | Private Key of 'certificates.group.peer.certificatePEM'                                                                                                                               | `""`      |
| `certificates.group.peer.existingSecret`                                   | Use existing secret with your OpenFSC keypair (`certificates.group.peer.certificatePEM` and `certificates.group.peer.keyPEM` will be ignored and picked up from the secret)           | `""`      |
| `certificates.group.peer.certificatePEM`                                   | PEM certificates for the peer                                                                                                                                                         | `""`      |
| `certificates.group.token.keyPEM`                                          | Private Key of 'certificates.group.token.certificatePEM'                                                                                                                              | `""`      |
| `certificates.group.token.existingSecret`                                  | Use existing secret with your OpenFSC keypair (`certificates.group.token.certificatePEM` and `certificates.group.token.keyPEM` will be ignored and picked up from the secret)         | `""`      |
| `certificates.group.token.certificatePEM`                                  | PEM certificates for the signing tokens                                                                                                                                               | `""`      |
| `certificates.group.signature.certificatePEM`                              | The certificate used to create signatures for Contracts                                                                                                                               | `""`      |
| `certificates.group.signature.keyPEM`                                      | Private Key of 'certificates.group.signature.certificatePEM'                                                                                                                          | `""`      |
| `certificates.group.signature.existingSecret`                              | Use existing secret with your OpenFSC keypair (`certificates.group.signature.certificatePEM` and `certificates.group.signature.keyPEM` will be ignored and picked up from the secret) | `""`      |

### OpenFSC PostgreSQL Parameters

| Name                                    | Description                                                                                                                              | Value              |
| --------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------- | ------------------ |
| `postgresql.hostname`                   | PostgreSQL hostname                                                                                                                      | `postgresql`       |
| `postgresql.port`                       | PostgreSQL port                                                                                                                          | `5432`             |
| `postgresql.database`                   | PostgreSQL database                                                                                                                      | `open_fsc_manager` |
| `postgresql.migrationDSNParams`         | Additional parameters to be added to the PostgresDSN                                                                                     | `""`               |
| `postgresql.username`                   | PostgreSQL username. Will be stored in a Kubernetes secret                                                                               | `""`               |
| `postgresql.password`                   | PostgreSQL password. Will be stored in a Kubernetes secret                                                                               | `""`               |
| `postgresql.sslMode`                    | PostgreSQL SSL mode                                                                                                                      | `require`          |
| `postgresql.connectTimeout`             | The connection timeout for PostgreSQL                                                                                                    | `10`               |
| `postgresql.existingSecret.name`        | Use existing secret for password details ('postgresql.username' and 'postgresql.password' will be ignored and picked up from this secret | `""`               |
| `postgresql.existingSecret.usernameKey` | Key for username value in aforementioned existingSecret                                                                                  | `username`         |
| `postgresql.existingSecret.passwordKey` | Key for password value in aforementioned existingSecret                                                                                  | `password`         |

### Exposure parameters

| Name                                   | Description                                          | Value       |
| -------------------------------------- | ---------------------------------------------------- | ----------- |
| `service.external.type`                | Service Type (ClusterIP, NodePort, LoadBalancer)     | `ClusterIP` |
| `service.external.port`                | Port exposed by the external service                 | `8443`      |
| `service.external.annotations`         | annotations added to the external service            | `{}`        |
| `service.internal.type`                | Service Type (ClusterIP, NodePort, LoadBalancer)     | `ClusterIP` |
| `service.internal.port`                | Port exposed by the internal service                 | `9443`      |
| `service.internalUnauthenticated.type` | Service Type (ClusterIP, NodePort, LoadBalancer)     | `ClusterIP` |
| `service.internalUnauthenticated.port` | Port exposed by the internal unauthenticated service | `9444`      |

Specify each parameter using the `--set key=value[,key=value]` argument to `helm install`.

Alternatively, a YAML file that specifies the values for the above parameters can be provided while installing the chart.

```console
$ helm install manager -f values.yaml .
```

> **Tip**: You can use the default [values.yaml](https://gitlab.com/rinis-oss/fsc/open-fsc/blob/main/helm/charts/open-fsc-manager/values.yaml)
